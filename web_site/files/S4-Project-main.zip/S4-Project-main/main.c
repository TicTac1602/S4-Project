#include "main.h"

int main(int argc,char* argv[]){
	int status = app(argc,argv);
	status = status+0;
}
